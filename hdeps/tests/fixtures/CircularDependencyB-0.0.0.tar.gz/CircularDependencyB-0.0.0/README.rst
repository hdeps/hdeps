CircularDependencyA and CircularDependencyB
===========================================

Two packages that depend on each other - i.e.: a circular dependency

For testing the behavior of packaging tools like pipdeptree, pip, etc.
